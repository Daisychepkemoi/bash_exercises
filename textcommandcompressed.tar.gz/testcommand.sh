#! /bin/bash
echo "Hello $USER"
echo "Welcome Back!"